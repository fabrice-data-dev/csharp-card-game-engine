using System;
using System.Collections.Generic;
using System.Linq;
using FishingCardGame.Models.Structs;

namespace FishingCardGame.Models.Classes 
{
    // Classe repr�sentant la pile de d�p�t (cartes jou�es sur la table)
    public class DepositStack
    {
        private List<Card> cards; // Liste priv�e contenant toutes les cartes dans la pile

        // Propri�t� en lecture seule renvoyant la derni�re carte d�pos�e
        // Si la pile est vide, renvoie null
        public Card? LastCard => cards.Count > 0 ? cards.Last() : null;

        // Propri�t� en lecture seule renvoyant le nombre total de cartes dans la pile
        public int Count => cards.Count;

        public DepositStack()
        {
            cards = new List<Card>();
        }

        // D�pose une carte sur la pile
        public void Deposit(Card card)
        {
            cards.Add(card);
        }

        // Prend toutes les cartes sauf la derni�re et les m�lange
        public List<Card> TakeAllExceptLast()
        {
            // Si la pile contient 0 ou 1 carte, rien � prendre
            if (cards.Count <= 1)
                return new List<Card>();

            // Prend toutes les cartes sauf la derni�re
            var result = cards.Take(cards.Count - 1).ToList();

            // Garde uniquement la derni�re carte dans la pile
            cards = new List<Card> { cards.Last() };

            // M�lange les cartes prises
            ShuffleCards(result);

            // Renvoie les cartes m�lang�es
            return result;
        }

        // M�thode priv�e pour m�langer une liste de cartes (algorithme de Fisher-Yates)
        private void ShuffleCards(List<Card> cardsToShuffle)
        {
            var rng = new Random(); // G�n�rateur de nombres al�atoires
            for (int i = cardsToShuffle.Count - 1; i > 0; i--)
            {
                int j = rng.Next(i + 1); // Choix d�un index al�atoire
                (cardsToShuffle[i], cardsToShuffle[j]) = (cardsToShuffle[j], cardsToShuffle[i]); // �change des cartes
            }
        }
    }
}