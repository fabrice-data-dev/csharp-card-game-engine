// C:\Users\PC\Desktop\Etude Quebec Alhamduliallah\S5\Concepts avancés en objet\TP1\FishingCardGame\Models\Classes\DrawStack.cs
using System;
using System.Collections.Generic;
using FishingCardGame.Models.Structs;

namespace FishingCardGame.Models.Classes
{
    // Classe représentant la pile de pioche (DrawStack) pour tirer les cartes
    public class DrawStack
    {
        private Stack<Card> cards; // Pile interne contenant les cartes à tirer

        // Événement déclenché lorsque la pile est vide
        public event EventHandler? StackEmpty;

        // Événement déclenché lorsque la pile est remplie
        public event EventHandler? StackRefilled;

        // Nombre de cartes actuellement dans la pile
        public int Count => cards.Count;

        // Indique si la pile est vide
        public bool IsEmpty => cards.Count == 0;

        // Constructeur : initialise la pile vide
        public DrawStack()
        {
            cards = new Stack<Card>();
        }

        // Ajoute une liste de cartes dans la pile
        public void AddCards(List<Card> newCards)
        {
            if (newCards == null)
                throw new ArgumentNullException(nameof(newCards)); // Sécurité : la liste ne doit pas être nulle

            // Empile chaque carte dans la pile
            foreach (var card in newCards)
            {
                cards.Push(card);
            }

            // Si on a ajouté au moins une carte et que la pile était vide avant, on déclenche StackRefilled
            if (newCards.Count > 0 && cards.Count == newCards.Count)
            {
                StackRefilled?.Invoke(this, EventArgs.Empty);
            }
        }

        // Tire une carte depuis la pile
        public Card Draw()
        {
            // Si la pile est vide, déclenche l’événement StackEmpty et lève une exception
            if (IsEmpty)
            {
                StackEmpty?.Invoke(this, EventArgs.Empty);
                throw new InvalidOperationException("Impossible de piocher: pile vide");
            }

            // Récupère et retire la carte du haut de la pile
            var card = cards.Pop();

            // Si la pile est maintenant vide, déclenche StackEmpty
            if (IsEmpty)
            {
                StackEmpty?.Invoke(this, EventArgs.Empty);
            }

            return card; // Retourne la carte piochée
        }

        // Vide complètement la pile
        public void Clear()
        {
            cards.Clear();               // Supprime toutes les cartes
            StackEmpty?.Invoke(this, EventArgs.Empty); // Déclenche l’événement pile vide
        }
    }
}