// C:\Users\PC\Desktop\Etude Quebec Alhamduliallah\S5\Concepts avancés en objet\TP1\FishingCardGame\Models\Classes\Player.cs
using System;
using System.Collections.Generic; 
using System.Linq;
using FishingCardGame.Models.Interfaces;
using FishingCardGame.Models.Structs;
using FishingCardGame.Models.Enums;

namespace FishingCardGame.Models.Classes 
{
    // Classe Player représentant un joueur dans le jeu de cartes
    // Implémente l’interface Person (Nom, Prenom, Identifiant)
    public class Player : Person
    {
        // Nom du joueur (propriété en lecture publique et écriture privée)
        public string Nom { get; private set; }

        // Prénom du joueur (propriété en lecture publique et écriture privée)
        public string Prenom { get; private set; }

        // Identifiant unique du joueur, généré automatiquement via Guid
        public Guid Identifiant { get; private set; }

        // Liste des cartes actuellement détenues par le joueur
        public List<Card> Hand { get; private set; }

        // Indique si le joueur utilise une stratégie automatique (IA, par exemple)
        public bool UseStrategy { get; set; }

        // Événement déclenché lorsqu’une carte est jouée
        public event EventHandler<Card>? CardPlayed;

        // Événement déclenché lorsqu’il ne reste qu’une seule carte dans la main
        public event EventHandler? OneCardLeft;

        // Événement déclenché lorsque le joueur pioche une ou plusieurs cartes
        public event EventHandler<int>? CardsDrawn;

        // Événement déclenché lorsque le joueur passe son tour
        public event EventHandler? TurnSkipped;

        // Constructeur du joueur : initialise les propriétés de base
        public Player(string nom, string prenom)
        {
            Nom = nom;                         // Affecte le nom
            Prenom = prenom;                   // Affecte le prénom

            // Génère un GUID unique pour le joueur
            Identifiant = Guid.NewGuid();

            Hand = new List<Card>();           // Initialise la main vide
            UseStrategy = false;               // Par défaut, le joueur ne suit pas de stratégie automatique
        }

        // Propriété calculée pour obtenir un identifiant court à 7 caractères
        public string ShortId => Identifiant.ToString("N").Substring(0, 7).ToUpper();

        // Ajoute une carte à la main du joueur si elle contient moins de 8 cartes
        public void AddCard(Card card)
        {
            if (Hand.Count < 8)
            {
                Hand.Add(card);
            }
        }

        // Retire une carte de la main du joueur
        public void RemoveCard(Card card)
        {
            Hand.Remove(card);

            // Si le joueur n’a plus qu’une seule carte, on déclenche l’événement correspondant
            if (Hand.Count == 1)
            {
                OneCardLeft?.Invoke(this, EventArgs.Empty);
            }
        }

        // Joue une carte : la retire de la main et déclenche l’événement CardPlayed
        public void PlayCard(Card card)
        {
            RemoveCard(card);               // Supprime la carte de la main
            CardPlayed?.Invoke(this, card); // Déclenche l’événement en passant la carte jouée
        }

        // Déclenche l’événement indiquant que le joueur a pioché des cartes
        public void DrawCards(int count)
        {
            CardsDrawn?.Invoke(this, count);
        }

        // Déclenche l’événement indiquant que le joueur passe son tour
        public void SkipTurn()
        {
            TurnSkipped?.Invoke(this, EventArgs.Empty);
        }

        // Détermine si le joueur possède au moins une carte jouable selon la dernière carte posée
        // ou la couleur choisie (dans le cas d’un changement de couleur)
        public bool HasPlayableCard(Card? lastCard, CardColor? chosenColor)
        {
            // Si aucune carte n’a encore été jouée, il suffit d’avoir une carte en main
            if (!lastCard.HasValue) return Hand.Count > 0;

            // Si une couleur a été choisie (par un Valet par exemple),
            // le joueur peut jouer une carte de cette couleur ou un Valet
            if (chosenColor.HasValue)
            {
                return Hand.Any(c => c.Color.Equals(chosenColor.Value) || c.Value == CardValue.Valet);
            }

            // Sinon, il peut jouer :
            // - une carte de la même couleur,
            // - une carte de la même valeur,
            // - ou un Valet (sauf si la dernière carte est un Deux)
            return Hand.Any(c => c.Color.Equals(lastCard.Value.Color) ||
                                c.Value == lastCard.Value.Value ||
                                (c.Value == CardValue.Valet && lastCard.Value.Value != CardValue.Deux));
        }

        // Redéfinition de ToString pour afficher le nom complet du joueur
        public override string ToString() => $"[ID:{ShortId}] {Prenom} {Nom}";
    }
}