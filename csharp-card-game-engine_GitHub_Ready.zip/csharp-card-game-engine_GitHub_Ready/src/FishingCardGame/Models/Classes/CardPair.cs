using System;
using System.Collections.Generic;

using FishingCardGame.Models.Structs;
using FishingCardGame.Models.Enums;

namespace FishingCardGame.Models.Classes 
{
    // Classe repr�sentant un ensemble complet de cartes (paire ou deck)
    public class CardPair
    {
        private List<Card> cards; // Liste priv�e contenant toutes les cartes du deck

        public CardPair()
        {
            cards = new List<Card>(); // Cr�ation d�une nouvelle liste vide
            GenerateDeck();           // G�n�ration de toutes les cartes standard
        }

        // M�thode priv�e pour cr�er toutes les cartes (52 cartes) du jeu
        private void GenerateDeck()
        {
            // Liste des couleurs disponibles dans le jeu
            var colors = new List<CardColor>
            {
                CardColor.CreateTrefle(),  // Tr�fle
                CardColor.CreateCarreau(), // Carreau
                CardColor.CreateCoeur(),   // Coeur
                CardColor.CreatePique()    // Pique
            };

            // Boucle sur chaque couleur
            foreach (var color in colors)
            {
                // Boucle sur chaque valeur possible (As, 2, ..., Roi)
                foreach (CardValue value in Enum.GetValues(typeof(CardValue)))
                {
                    // Cr�e une carte avec la valeur et la couleur et l�ajoute au deck
                    cards.Add(new Card(value, color));
                }
            }
        }

        // Renvoie une **nouvelle copie** de la liste de cartes pour �viter la modification directe
        public List<Card> GetCards() => new List<Card>(cards);

        // M�lange les cartes du deck avec l�algorithme de Fisher-Yates
        public void Shuffle()
        {
            var rng = new Random(); // G�n�re un g�n�rateur de nombres al�atoires
            int n = cards.Count;    // Nombre total de cartes

            // Boucle pour �changer les cartes al�atoirement
            while (n > 1)
            {
                n--; // D�cr�mente l�index
                int k = rng.Next(n + 1);          // Choix d�un index al�atoire
                (cards[k], cards[n]) = (cards[n], cards[k]); // �change cartes[k] et cartes[n]
            }
        }
    }
}