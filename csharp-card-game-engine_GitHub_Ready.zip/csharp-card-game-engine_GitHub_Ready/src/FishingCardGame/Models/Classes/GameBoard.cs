// C:\Users\PC\Desktop\Etude Quebec Alhamduliallah\S5\Concepts avancés en objet\TP1\FishingCardGame\Models\Classes\GameBoard.cs
using System;
using FishingCardGame.Models.Structs;

namespace FishingCardGame.Models.Classes
{
    // Classe représentant le plateau de jeu, gérant les piles et la couleur choisie
    public class GameBoard
    {
        // Pile de pioche
        public DrawStack DrawStack { get; private set; }

        // Pile de dépôt (cartes jouées)
        public DepositStack DepositStack { get; private set; }

        // Couleur choisie par un joueur (ex: après avoir joué un Valet)
        public CardColor? ChosenColor { get; set; }

        // Événement pour notifier l’état du plateau (pile vide, reapprovisionnement, couleur choisie)
        public event EventHandler<string>? GameBoardEvent;

        // Constructeur : initialise les piles et abonne les événements
        public GameBoard()
        {
            DrawStack = new DrawStack();       // Création de la pile de pioche
            DepositStack = new DepositStack(); // Création de la pile de dépôt
            ChosenColor = null;                // Aucune couleur choisie au départ

            // Abonne les méthodes aux événements de DrawStack
            DrawStack.StackEmpty += OnDrawStackEmpty;
            DrawStack.StackRefilled += OnDrawStackRefilled;
        }

        // Méthode appelée lorsque la pile de pioche est vide
        private void OnDrawStackEmpty(object? sender, EventArgs e)
        {
            GameBoardEvent?.Invoke(this, "Pile de pioche vide! Reapprovisionnement necessaire.");
        }

        // Méthode appelée lorsque la pile de pioche est reapprovisionnée
        private void OnDrawStackRefilled(object? sender, EventArgs e)
        {
            GameBoardEvent?.Invoke(this, "Pile de pioche reapprovisionnée!");
        }

        // Reapprovisionne la pile de pioche à partir de la pile de dépôt (sauf la dernière carte)
        public void RefillDrawStack()
        {
            // Vérifie que la pioche est vide et que la pile de dépôt a plus d'une carte
            if (DrawStack.IsEmpty && DepositStack.Count > 1)
            {
                // Prend toutes les cartes sauf la dernière
                var cards = DepositStack.TakeAllExceptLast();

                // Si on a récupéré des cartes, on les ajoute à la pioche
                if (cards.Count > 0)
                {
                    DrawStack.AddCards(cards);
                    GameBoardEvent?.Invoke(this, $"Pile reapprovisionnée avec {cards.Count} cartes melangées");
                }
            }
        }

        // Réinitialise la couleur choisie à null
        public void ResetChosenColor()
        {
            ChosenColor = null;
        }

        // Définit la couleur choisie et notifie l’événement
        public void SetChosenColor(CardColor color)
        {
            ChosenColor = color;
            GameBoardEvent?.Invoke(this, $"Nouvelle couleur imposée: {color}");
        }
    }
}