﻿// C:\Users\PC\Desktop\Etude Quebec Alhamduliallah\S5\Concepts avancés en objet\TP1\FishingCardGame\Models\Game\CardEffectHandler.cs
using System;                                              
using System.Linq;                                         
using FishingCardGame.Models.Structs;                      
using FishingCardGame.Models.Enums;                        
using FishingCardGame.Models.Classes;                      
using FishingCardGame.Models.Events;                       

namespace FishingCardGame.Models.Game                      
{
    /// <summary>
    /// Gère les effets des cartes spéciales
    /// Centralise la logique des effets : +2, skip, inversion, choix couleur
    /// </summary>
    public class CardEffectHandler                          
    {
        // === Événements publics exposés vers le moteur principal (FishingGame) ===
        public event EventHandler<DirectionChangedEventArgs>? DirectionChanged; // Inversion du sens
        public event EventHandler<PlayerSkippedEventArgs>? NextPlayerSkipped;   // Saut du prochain joueur
        public event EventHandler<PenaltyEventArgs>? PenaltyCardsAdded;         // Cumul de pénalité (+2)
        public event EventHandler<ColorChosenEventArgs>? ColorChosen;           // Couleur choisie après un Valet

        // === États internes de contrôle ===
        private bool skipNextPlayer;                         // Indique si le prochain joueur doit être sauté
        private int penaltyCards;                            // Nombre de cartes de pénalité cumulées
        private bool penaltyActive;                          // True si une chaîne de 2 est en cours (+2 cumulatif)

        // === Propriétés publiques de lecture ===
        public bool ShouldSkipNextPlayer => skipNextPlayer;   // Lecture seule : indique si le prochain doit passer
        public int PenaltyCards => penaltyCards;              // Nombre total de cartes à piocher
        public bool IsPenaltyActive => penaltyActive;         // True si la pénalité est en cours

        public CardEffectHandler()                            // Constructeur : initialise les états neutres
        {
            skipNextPlayer = false;
            penaltyCards = 0;
            penaltyActive = false;
        }

        /// <summary>
        /// Applique l'effet d'une carte jouée
        /// </summary>
        public void ApplyCardEffect(                          // Détermine le comportement selon la carte jouée
            Card card,                                        // Carte posée
            Player player,                                    // Joueur ayant joué la carte
            CardColor? chosenColorForJack = null)             // Couleur choisie (uniquement si Valet)
        {
            switch (card.Value)                               // Analyse du type de carte
            {
                case CardValue.As:                            // Cas de l’As → effet “Skip”
                    skipNextPlayer = true;                    // Active le saut
                    NextPlayerSkipped?.Invoke(this,            // Notifie les abonnés (par ex. moteur principal)
                        new PlayerSkippedEventArgs { SkippedPlayer = null });
                    Console.WriteLine("  Effet As: Prochain joueur saute son tour!"); // Log console
                    break;

                case CardValue.Deux:                          // Cas du 2 → effet “+2”
                    penaltyCards += 2;                        // Ajoute deux cartes de pénalité cumulatives
                    penaltyActive = true;                     // Active le mode pénalité
                    PenaltyCardsAdded?.Invoke(this,            // Notifie l’ajout
                        new PenaltyEventArgs { PenaltyCount = penaltyCards });
                    Console.WriteLine($"  Effet 2: Pénalité cumulative = {penaltyCards} cartes!"); // Log console
                    break;

                case CardValue.Dix:                           // Cas du 10 → effet “Inversion de sens”
                    DirectionChanged?.Invoke(this,             // Émet l’événement d’inversion
                        new DirectionChangedEventArgs { Clockwise = false }); // (sens “à inverser”)
                    Console.WriteLine("  Effet 10: Direction inversée!");     // Log
                    break;

                case CardValue.Valet:                         // Cas du Valet → effet “choix de couleur”
                    if (chosenColorForJack.HasValue)           // Si une couleur a été choisie par la stratégie
                    {
                        ColorChosen?.Invoke(this,              // Déclenche l’événement
                            new ColorChosenEventArgs { ChosenColor = chosenColorForJack.Value });
                        Console.WriteLine($"  Effet Valet: Nouvelle couleur = {chosenColorForJack.Value}"); // Log
                    }
                    break;
            }
        }

        /// <summary>
        /// Vérifie si le joueur peut contrer un +2
        /// </summary>
        public bool CanCounter(Player player)
        {
            return penaltyActive &&                           // Une pénalité est en cours
                   player.Hand.Any(c => c.Value == CardValue.Deux); // Le joueur possède un 2
        }

        /// <summary>
        /// Récupère une carte de contre (+2) si possible
        /// </summary>
        public Card? GetCounterCard(Player player)
        {
            if (!penaltyActive) return null;                  // Aucun effet actif → pas de contre possible
            return player.Hand.FirstOrDefault(c => c.Value == CardValue.Deux); // Retourne la première carte “2” trouvée
        }

        /// <summary>
        /// Applique la fin de la pénalité (le joueur a pioché)
        /// </summary>
        public void ApplyPenaltyComplete()
        {
            skipNextPlayer = true;                            // Le joueur suivant saute (conséquence du +2)
            penaltyCards = 0;                                 // Réinitialise le compteur
            penaltyActive = false;                            // Désactive la chaîne de pénalité
        }

        /// <summary>
        /// Réinitialise le drapeau “skip” (après un tour sauté)
        /// </summary>
        public void ResetSkip()
        {
            skipNextPlayer = false;                           // Plus de saut en attente
        }
    }
}
