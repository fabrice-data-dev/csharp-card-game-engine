// C:\Users\PC\Desktop\Etude Quebec Alhamduliallah\S5\Concepts avancés en objet\TP1\FishingCardGame\Models\Game\FishingGame.cs
using System;                                           
using System.Collections.Generic;                       
using System.Linq;                                      
using System.Threading.Tasks;                          
using FishingCardGame.Models.Classes;                   
using FishingCardGame.Models.Structs;                   
using FishingCardGame.Models.Enums;                     
using FishingCardGame.Models.Events;                    

namespace FishingCardGame.Models.Game                  
{
    /// <summary>
    /// Classe principale gérant le jeu de pêche
    /// </summary>
    public class FishingGame                               
    {
        private List<Player> players;                      // Liste des joueurs inscrits à la partie
        private GameBoard gameBoard;                       // Plateau de jeu (piles de pioche/défausse, état courant)
        private CardPair cardPair;                         // Paquet de cartes (double jeu/paire selon règles)
        private GameRules rules;                           // Règles (si nécessaire pour validations/paramètres)
        private CardEffectHandler effectHandler;           // Gestionnaire des effets de cartes (skip, +2, sens, etc.)
        private GameStrategy strategy;                     // Moteur de décision (carte “intelligente”, choix de couleur)

        private int currentPlayerIndex;                    // Index du joueur courant dans la liste
        private bool clockwise;                            // Sens de jeu : true = horaire, false = antihoraire
        private Dictionary<Player, bool> playersShouldPreventWin; // Drapeau “défense/empêcher victoire” par joueur
        private Player? playerWithOneCard;                 // Référence au joueur qui n’a plus qu’une seule carte (alerte)

        public event EventHandler<GameEndedEventArgs>? GameEnded; // Événement de fin de partie (scores, gagnant)

        public FishingGame()                               
        {
            players = new List<Player>();                  // Crée la liste de joueurs
            gameBoard = new GameBoard();                   // Instancie le plateau
            cardPair = new CardPair();                     // Crée/charge le paquet de cartes
            rules = new GameRules();                       // Règles (placeholder pour extensions)
            effectHandler = new CardEffectHandler();       // Gestionnaire des effets
            strategy = new GameStrategy();                 // Stratégie de jeu

            clockwise = true;                              // Sens initial : horaire
            playersShouldPreventWin = new Dictionary<Player, bool>(); // Dictionnaire de défense
            playerWithOneCard = null;                      // Pas d’alerte au départ

            effectHandler.DirectionChanged += OnDirectionChanged; // Abonnement : quand une carte inverse le sens
            effectHandler.ColorChosen += OnColorChosen;           // Abonnement : choix de couleur (Valet)
            gameBoard.GameBoardEvent += OnGameBoardEvent;         // Abonnement : logs du plateau
        }

        private void OnDirectionChanged(object? sender, DirectionChangedEventArgs e) // Callback inversion de sens
        {
            clockwise = !clockwise;                        // Inverse le booléen de direction
        }

        private void OnColorChosen(object? sender, ColorChosenEventArgs e) // Callback choix de couleur
        {
            gameBoard.SetChosenColor(e.ChosenColor);       // Mémorise la couleur imposée sur le plateau
        }

        private void OnGameBoardEvent(object? sender, string message) // Callback messages du plateau
        {
            Console.WriteLine($"[PLATEAU] {message}");     // Affiche le message dans la console
        }

        public void AddPlayer(Player player)               // Ajoute un joueur à la partie
        {
            if (players.Count >= 4)                        // Vérifie le plafond de joueurs
                throw new InvalidOperationException("Maximum 4 joueurs"); // Lève si dépassement

            players.Add(player);                           // Ajoute à la liste
            playersShouldPreventWin[player] = false;       // Par défaut, pas en mode “empêcher victoire”

            player.OneCardLeft += OnPlayerOneCardLeft;     // Abonnement : alerte une carte restante
            player.CardPlayed += OnCardPlayed;             // Abonnement : lorsqu’une carte est jouée
            player.CardsDrawn += OnCardsDrawn;             // Abonnement : lorsqu’il pioche
            player.TurnSkipped += OnTurnSkipped;           // Abonnement : lorsqu’un tour est sauté
        }

        private void OnPlayerOneCardLeft(object? sender, EventArgs e) // Callback “une carte restante”
        {
            var player = sender as Player;                 // Récupère le joueur émetteur
            if (player == null) return;                    // Sécurité null

            Console.WriteLine($"\n*** ALERTE: {player} n'a plus qu'UNE CARTE! ***"); // Log alerte
            playerWithOneCard = player;                    // Mémorise le joueur en alerte

            foreach (var p in players.Where(p => p != player)) // Tous les autres joueurs…
            {
                playersShouldPreventWin[p] = true;         // …passent en mode défense (empêcher sa victoire)
            }
        }

        private void OnCardPlayed(object? sender, Card card) // Callback carte jouée
        {
            var player = sender as Player;                 // Récupère le joueur
            Console.WriteLine($"  {player} joue: {card}"); // Affiche l’action
        }

        private void OnCardsDrawn(object? sender, int count) // Callback pioche
        {
            var player = sender as Player;                 // Récupère le joueur
            Console.WriteLine($"  {player} pioche {count} carte(s)"); // Log pioche
        }

        private void OnTurnSkipped(object? sender, EventArgs e) // Callback tour sauté
        {
            var player = sender as Player;                 // Récupère le joueur
            Console.WriteLine($"  {player}: Tour sauté!"); // Log
        }

        public async Task StartGame(int cardsPerPlayer = 7) // Démarre la partie (asynchrone)
        {
            if (players.Count < 2 || players.Count > 4)    // Vérifie bornes du nombre de joueurs
                throw new InvalidOperationException("2-4 joueurs requis"); // Lève erreur si invalide

            if (cardsPerPlayer < 5 || cardsPerPlayer > 8)  // Vérifie bornes de distribution
                throw new ArgumentException("5-8 cartes par joueur"); // Lève erreur si invalide

            Console.WriteLine("\n╔════════════════════════════════════╗"); // Habillage console
            Console.WriteLine("║       JEU DE PÊCHE - DÉBUT        ║");
            Console.WriteLine("╚════════════════════════════════════╝\n");
            Console.WriteLine($"Joueurs ({players.Count}): {string.Join(", ", players)}"); // Liste joueurs
            Console.WriteLine($"Cartes par joueur: {cardsPerPlayer}");                     // Info distribution

            var rng = new Random();                           // Générateur aléatoire
            var strategyPlayer = players[rng.Next(players.Count)]; // Sélectionne un joueur au hasard
            strategyPlayer.UseStrategy = true;                // Active la stratégie “minimisation” pour ce joueur
            Console.WriteLine($"\n>>> Stratégie de minimisation: {strategyPlayer} <<<"); // Log stratégie

            DistributeCards(cardsPerPlayer);                  // Distribution des cartes

            currentPlayerIndex = rng.Next(players.Count);     // Tire au sort le premier joueur
            Console.WriteLine($"Premier joueur: {players[currentPlayerIndex]}"); // Log premier joueur
            Console.WriteLine(new string('─', 40));           // Séparateur visuel

            await PlayGame();                                 // Lance la boucle de jeu principale
        }

        private void DistributeCards(int cardsPerPlayer)      // Distribution initiale
        {
            cardPair.Shuffle();                               // Mélange le paquet
            var allCards = cardPair.GetCards();               // Récupère la liste des cartes
            int cardIndex = 0;                                // Index de distribution

            for (int i = 0; i < cardsPerPlayer; i++)          // Pour chaque “tour” de distribution
            {
                foreach (var player in players)               // Pour chaque joueur
                {
                    player.AddCard(allCards[cardIndex++]);    // Donne une carte et incrémente l’index
                }
            }

            var remainingCards = allCards.Skip(cardIndex).ToList(); // Reste des cartes non distribuées
            gameBoard.DrawStack.AddCards(remainingCards);     // Met les restantes dans la pioche

            Console.WriteLine($"\nDistribution terminée:");   // Log fin distribution
            Console.WriteLine($"  Pioche: {gameBoard.DrawStack.Count} cartes"); // Taille pioche
            foreach (var p in players)                        // Pour chaque joueur
            {
                Console.WriteLine($"  {p}: {p.Hand.Count} cartes"); // Taille main
            }
        }

        private async Task PlayGame()                         // Boucle principale de jeu (asynchrone)
        {
            var currentPlayer = players[currentPlayerIndex];  // Récupère le joueur courant
            var rng = new Random();                           // Aléatoire

            // Premier joueur joue une carte aléatoire
            var firstCard = currentPlayer.Hand[rng.Next(currentPlayer.Hand.Count)]; // Tire une carte aléatoire de sa main
            Console.WriteLine($"\n{currentPlayer} commence avec: {firstCard}");     // Log
            currentPlayer.PlayCard(firstCard);                // Retire de la main + déclenche événements joueurs
            gameBoard.DepositStack.Deposit(firstCard);        // Dépose sur la pile de défausse

            // Pas d'effet spécial pour la première carte sauf le 10
            if (firstCard.Value == CardValue.Dix)             // Si c’est un “10”
            {
                effectHandler.ApplyCardEffect(firstCard, currentPlayer); // Applique son effet (ex: changer sens, etc.)
            }

            if (currentPlayer.Hand.Count == 0)                // Si le 1er joueur a tout joué (cas extrême)
            {
                await AnnounceWinner(currentPlayer);          // Annonce la victoire
                return;                                       // Termine la partie
            }

            MoveToNextPlayer();                                // Passe au joueur suivant
            await Task.Delay(500);                             // Petite pause “visuelle”

            int turnNumber = 1;                                // Compteur de tours

            while (true)                                       // Boucle jusqu’à victoire ou arrêt
            {
                currentPlayer = players[currentPlayerIndex];   // Récupère le joueur courant
                Console.WriteLine($"\n╔═══ Tour {++turnNumber}: {currentPlayer} ═══╗"); // Entête de tour
                Console.WriteLine($"Direction: {(clockwise ? "-> horaire" : "<- anti-horaire")}"); // Sens actuel
                Console.WriteLine($"Dernière carte: {gameBoard.DepositStack.LastCard}");         // Carte au sommet

                if (gameBoard.ChosenColor.HasValue)            // Si une couleur est imposée (Valet)
                {
                    Console.WriteLine($"Couleur imposée: {gameBoard.ChosenColor}"); // Affiche la contrainte
                }

                Console.WriteLine($"Main: {currentPlayer.Hand.Count} cartes"); // Taille de la main

                // Gestion du saut de tour
                if (effectHandler.ShouldSkipNextPlayer)        // S’il faut sauter ce joueur
                {
                    currentPlayer.SkipTurn();                  // Émet l’événement de tour sauté
                    effectHandler.ResetSkip();                 // Réinitialise l’état “skip”
                    MoveToNextPlayer();                        // Passe au suivant
                    await Task.Delay(300);                     // Petite pause
                    continue;                                  // Reboucle
                }

                // Gestion des pénalités (cartes 2)
                if (effectHandler.IsPenaltyActive)             // Si une pénalité cumulée est active (+2, etc.)
                {
                    var counter = effectHandler.GetCounterCard(currentPlayer); // Cherche une carte de contre

                    if (counter.HasValue && counter.Value.IsValid) // S’il peut contrer
                    {
                        // Jouer le contre
                        currentPlayer.PlayCard(counter.Value); // Joue la carte de contre
                        gameBoard.DepositStack.Deposit(counter.Value); // Dépose sur la défausse
                        effectHandler.ApplyCardEffect(counter.Value, currentPlayer); // Propage l’effet (augmente pénalité)
                        Console.WriteLine($"  >>> CONTRE! Pénalité totale: {effectHandler.PenaltyCards} cartes"); // Log

                        if (currentPlayer.Hand.Count == 0)     // S’il a tout joué
                        {
                            await AnnounceWinner(currentPlayer);// Victoire
                            break;                              // Sort de la boucle
                        }

                        CheckAndResetDefense(currentPlayer);    // Vérifie si on sort du mode défense
                    }
                    else
                    {
                        // Subir la pénalité
                        int penalty = effectHandler.PenaltyCards;        // Nombre de cartes à piocher
                        Console.WriteLine($"  SIGNAL: {currentPlayer} subit {penalty} cartes de pénalité!"); // Log

                        for (int i = 0; i < penalty; i++)               // Pioche “penalty” cartes
                        {
                            DrawCardForPlayer(currentPlayer);           // Pioche 1
                        }

                        currentPlayer.DrawCards(penalty);               // Déclenche l’événement “pioche X”
                        effectHandler.ApplyPenaltyComplete();           // Réinitialise l’état de pénalité

                        CheckAndResetDefense(currentPlayer);            // Peut désactiver la défense si conditions
                        MoveToNextPlayer();                             // Tour suivant
                        await Task.Delay(300);                          // Pause
                        continue;                                       // Reboucle
                    }
                }
                else
                {
                    // Tour normal
                    Card? cardToPlay = strategy.GetSmartCard(          // Demande à la stratégie quelle carte jouer
                        currentPlayer,
                        gameBoard.DepositStack.LastCard,                // Contexte : dernière carte
                        gameBoard.ChosenColor,                          // Contrainte couleur éventuelle
                        currentPlayer.UseStrategy,                      // Autorise l’IA pour ce joueur
                        playersShouldPreventWin[currentPlayer],         // Joue défensif si nécessaire
                        effectHandler.IsPenaltyActive                   // (Normalement false ici)
                    );

                    if (cardToPlay.HasValue && cardToPlay.Value.IsValid) // Une carte jouable a été choisie
                    {
                        currentPlayer.PlayCard(cardToPlay.Value);       // Joue la carte
                        gameBoard.DepositStack.Deposit(cardToPlay.Value); // Dépose

                        // Reset couleur choisie sauf pour Valet
                        if (cardToPlay.Value.Value != CardValue.Valet)  // Si ce n’est pas un Valet
                        {
                            gameBoard.ResetChosenColor();               // On libère la contrainte de couleur
                        }

                        // Appliquer effets
                        CardColor? chosenColor = null;                  // Choix de couleur (utilisé pour Valet)
                        if (cardToPlay.Value.Value == CardValue.Valet)  // Si c’est un Valet
                        {
                            var nextPlayerIdx = clockwise ?
                                (currentPlayerIndex + 1) % players.Count :
                                (currentPlayerIndex - 1 + players.Count) % players.Count; // Calcule le prochain joueur
                            chosenColor = strategy.ChooseColorForJack(  // L’IA choisit la meilleure couleur
                                currentPlayer, players, players[nextPlayerIdx]);
                        }

                        effectHandler.ApplyCardEffect(                  // Applique l’effet de la carte (skip, +2, sens…)
                            cardToPlay.Value, currentPlayer, chosenColor);

                        if (currentPlayer.Hand.Count == 0)              // Si le joueur s’est défaussé de toutes ses cartes
                        {
                            await AnnounceWinner(currentPlayer);        // Annonce victoire
                            break;                                      // Fin de la boucle
                        }

                        CheckAndResetDefense(currentPlayer);            // Vérifie/désactive la défense au besoin
                    }
                    else
                    {
                        Console.WriteLine($"  «« INFO: »» Aucune carte jouable! Pioche obligatoire."); // Aucun coup possible
                        DrawCardForPlayer(currentPlayer);               // Pioche une carte
                        currentPlayer.DrawCards(1);                     // Émet l’événement “pioche 1”
                        CheckAndResetDefense(currentPlayer);            // Mise à jour défense si besoin
                    }
                }

                MoveToNextPlayer();                                      // Passe au joueur suivant
                await Task.Delay(500);                                   // Petite pause

                if (turnNumber > 200)                                    // Garde-fou contre parties infinies
                {
                    Console.WriteLine("\n <> ATTENTION! => : Partie trop longue, arrêt forcé!"); // Log
                    await CalculateScores();                             // Calcule les scores actuels
                    break;                                               // Sort de la boucle
                }
            }
        }

        private void DrawCardForPlayer(Player player)                    // Pioche une carte pour un joueur
        {
            if (gameBoard.DrawStack.IsEmpty)                             // Si la pioche est vide
            {
                gameBoard.RefillDrawStack();                             // Reconstitue la pioche depuis la défausse
            }

            if (!gameBoard.DrawStack.IsEmpty)                            // Si on a de nouveau des cartes
            {
                player.AddCard(gameBoard.DrawStack.Draw());              // Donne la carte du dessus au joueur
            }
        }

        private void CheckAndResetDefense(Player player)                 // Réinitialise le mode “défense” si l’alerte est passée
        {
            if (playerWithOneCard == player && player.Hand.Count > 1)    // Si le joueur en alerte a repris >1 carte
            {
                playerWithOneCard = null;                                // Supprime l’alerte
                foreach (var p in players)                               // Pour tous les joueurs
                {
                    playersShouldPreventWin[p] = false;                  // Désactive le mode “empêcher victoire”
                }
                Console.WriteLine(" «*» ALERTE «*»: Défense désactivée ");             // Log
            }
        }

        private void MoveToNextPlayer()                                  // Incrémente l’index selon le sens
        {
            if (clockwise)                                               // Sens horaire
            {
                currentPlayerIndex = (currentPlayerIndex + 1) % players.Count; // Joueur suivant
            }
            else                                                         // Sens antihoraire
            {
                currentPlayerIndex = (currentPlayerIndex - 1 + players.Count) % players.Count; // Joueur précédent
            }
        }

        private async Task AnnounceWinner(Player winner)                 // Annonce la victoire d’un joueur
        {
            Console.WriteLine("\n╔════════════════════════╗");          // Habillage
            Console.WriteLine("║       VICTOIRE!        ║");
            Console.WriteLine("╚════════════════════════╝");
            Console.WriteLine($" *** Gagnant est: {winner} ***");                // Nom du gagnant
            Console.WriteLine("═══════════════════════════");            // Ligne

            await CalculateScores(winner);                               // Calcule les scores finaux et lève l’event
        }

        private async Task CalculateScores(Player? winner = null)        // Calcul et affichage des scores
        {
            Console.WriteLine("\n┌─── BILAN DES POINTS ───┐");           // En-tête

            var scores = players                                         // Pour chaque joueur…
                .Select(p => new {
                    Player = p,                                          // Référence joueur
                    Points = p.Hand.Sum(c => c.GetPoints()),             // Somme des points des cartes en main
                    Cards = p.Hand.Count                                 // Nombre de cartes restantes
                })
                .OrderBy(s => s.Points)                                  // Trie par points croissants
                .ToList();                                               // Matérialise en liste

            foreach (var score in scores)                                // Parcourt le classement
            {
                string status = (winner != null && score.Player == winner) ? " [GAGNANT]" : ""; // Marque le vainqueur
                Console.WriteLine($"│ {score.Player}: {score.Points} pts ({score.Cards} cartes){status}"); // Affiche

                if (score.Player.UseStrategy)                            // Si ce joueur avait l’IA active
                {
                    Console.WriteLine("│   «» Stratégie de minimisation «»"); // Mentionne la stratégie
                }
            }

            Console.WriteLine("└────────────────────────┘");             // Pied de section

            Console.WriteLine("\n╔═══ CLASSEMENT FINAL ═══╗");           // En-tête classement
            for (int i = 0; i < scores.Count; i++)                       // Pour chaque rang
            {
                string medal = i switch { 0 => "*** M.OR ***", 1 => "** M.ARGENT **", 2 => "* M.BRONZE *", _ => " " }; // Médailles top 3
                Console.WriteLine($"║ {medal} {i + 1}. {scores[i].Player}: {scores[i].Points} pts"); // Ligne classement
            }
            Console.WriteLine("╚═════════════════════════╝");            // Fin classement

            var scoresDict = scores.ToDictionary(s => s.Player, s => s.Points); // Dictionnaire Player→Points
            GameEnded?.Invoke(this, new GameEndedEventArgs { Winner = winner, Scores = scoresDict }); // Émet l’événement fin

            await Task.Delay(100);                                       // Petite pause (laisser le temps aux handlers)
        }
    }
}