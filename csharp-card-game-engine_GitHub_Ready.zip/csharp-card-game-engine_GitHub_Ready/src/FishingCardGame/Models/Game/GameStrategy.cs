﻿using System;                                              
using System.Collections.Generic;                          
using System.Linq;                                         
using FishingCardGame.Models.Structs;                      
using FishingCardGame.Models.Enums;                        
using FishingCardGame.Models.Classes;                      

namespace FishingCardGame.Models.Game                      
{
    /// <summary>
    /// Stratégies de jeu intelligentes
    /// </summary>
    public class GameStrategy                                // Contient les heuristiques de choix de carte/couleur
    {
        private GameRules rules;                             // Accès centralisé aux règles (cartes jouables, effets)
        private Random random;                               // Générateur aléatoire (pour choix de couleur fallback)

        public GameStrategy()                                // Ctor : initialise dépendances internes
        {
            rules = new GameRules();                         // Règles utilisées par les stratégies
            random = new Random();                           // RNG local
        }

        /// <summary>
        /// Obtient la meilleure carte pour minimiser les points
        /// </summary>
        public Card? GetBestCardForMinimization(             // Heuristique “minimisation des points”
            Player player,                                   // Joueur courant
            Card? lastCard,                                  // Dernière carte posée (peut être null en tout début)
            CardColor? chosenColor,                          // Couleur imposée (Valet), sinon null
            bool hasPenalty)                                 // Pénalité en cours (+2 cumul, etc.)
        {
            var playableCards = rules.GetPlayableCards(      // Filtre les cartes jouables selon règles/contexte
                player.Hand, lastCard, chosenColor, hasPenalty);

            if (playableCards.Count == 0) return null;       // Si rien de jouable → aucune carte proposée

            // Priorité 1: Se débarrasser des cartes à points élevés
            var highPointCards = playableCards                // Candidats à haute valeur (≥7 points)
                .Where(c => c.GetPoints() >= 7)
                .OrderByDescending(c => c.GetPoints());
            if (highPointCards.Any())                        // Si on en a…
            {
                // Éviter de jouer des cartes spéciales sauf si nécessaire
                var nonSpecial = highPointCards               // On préfère des “hautes” non-spéciales
                    .Where(c => !rules.HasSpecialEffect(c));
                if (nonSpecial.Any()) return nonSpecial.First(); // Joue la plus “coûteuse” non-spéciale
            }

            // Priorité 2: Jouer des cartes moyennes sans effet
            var mediumCards = playableCards                   // 4–6 points, sans effet
                .Where(c => c.GetPoints() >= 4 && c.GetPoints() < 7 && !rules.HasSpecialEffect(c));
            if (mediumCards.Any())                            // S’il y en a…
                return mediumCards.OrderByDescending(c => c.GetPoints()).First(); // Joue la plus lourde

            // Priorité 3: Garder les cartes spéciales pour la fin
            var normalCards = playableCards                   // Toute carte sans effet (quelque soit le score)
                .Where(c => !rules.HasSpecialEffect(c));
            if (normalCards.Any())                            // Si dispo…
                return normalCards.OrderByDescending(c => c.GetPoints()).First(); // Joue la plus lourde

            // Dernière option: jouer une carte spéciale
            return playableCards.First();                     // Sinon, on lâche la première spéciale disponible
        }

        /// <summary>
        /// Obtient la meilleure carte pour empêcher une victoire
        /// </summary>
        public Card? GetBestCardToPreventWin(                // Heuristique “bloquer la victoire adverse”
            Player player,                                   // Joueur courant
            Card? lastCard,                                  // Dernière carte posée
            CardColor? chosenColor,                          // Couleur imposée éventuelle
            bool hasPenalty)                                 // Pénalité en cours
        {
            var playableCards = rules.GetPlayableCards(      // Détermine les cartes jouables
                player.Hand, lastCard, chosenColor, hasPenalty);

            if (playableCards.Count == 0) return null;       // Rien à jouer → null

            // Priorité absolue: cartes qui font piocher ou sautent le tour
            var blockingCards = playableCards                 // Cible As (skip) et 2 (pénalité)
                .Where(c =>
                    c.Value == CardValue.Deux ||
                    c.Value == CardValue.As
                ).ToList();

            if (blockingCards.Any())                         // Si on peut bloquer immédiatement…
            {
                // Préférer le 2 pour maximum de pénalité
                var two = blockingCards.FirstOrDefault(c => c.Value == CardValue.Deux); // Cherche un 2
                if (two.IsValid) return two;                 // Si struct valide → jouer le 2
                return blockingCards.First();                // Sinon joue le premier (probablement un As)
            }

            // Changer la direction peut aider
            var ten = playableCards.FirstOrDefault(c => c.Value == CardValue.Dix); // Carte 10 (inverse sens)
            if (ten.IsValid) return ten;                    // Si dispo, on l’utilise

            // Changer la couleur pour une couleur que l'adversaire n'a probablement pas
            var jack = playableCards.FirstOrDefault(c => c.Value == CardValue.Valet); // Valet (choix de couleur)
            if (jack.IsValid) return jack;                  // Si dispo, on l’utilise

            // Sinon jouer normalement (retombe sur minimisation)
            return GetBestCardForMinimization(player, lastCard, chosenColor, hasPenalty);
        }

        /// <summary>
        /// Choix intelligent de couleur pour le Valet
        /// </summary>
        public CardColor ChooseColorForJack(                 // Choisit la couleur quand on pose un Valet
            Player player,                                   // Joueur qui joue le Valet
            List<Player> allPlayers,                         // Tous les joueurs (non utilisé ici sauf contexte)
            Player nextPlayer)                               // Prochain joueur (utile si à 1 carte)
        {
            // Analyser la main du joueur
            var colorGroups = player.Hand                    // Groupe les cartes (hors Valet) par couleur
                .Where(c => c.Value != CardValue.Valet)
                .GroupBy(c => c.Color)
                .Select(g => new {
                    Color = g.Key,                           // Couleur
                    Count = g.Count(),                       // Nb de cartes de cette couleur
                    TotalPoints = g.Sum(c => c.GetPoints())  // Somme des points (peut servir de tie-breaker)
                })
                .ToList();

            if (colorGroups.Any())                           // S’il a des cartes (hors Valet)
            {
                // Si le prochain joueur a une carte, choisir une couleur qu'on a mais qui bloque
                if (nextPlayer != null && nextPlayer.Hand.Count == 1) // Adversaire imminent à 1 carte
                {
                    // Choisir la couleur avec le plus de cartes spéciales
                    var bestBlockingColor = colorGroups
                        .OrderByDescending(g =>               // Trie d’abord par nb de “spéciales” de cette couleur
                            player.Hand.Count(c => c.Color.Equals(g.Color) && rules.HasSpecialEffect(c)))
                        .ThenByDescending(g => g.Count)       // Puis par quantité totale de cette couleur
                        .First();
                    return bestBlockingColor.Color;           // Renvoie la couleur jugée la plus “bloquante”
                }

                // Sinon choisir la couleur avec le plus de cartes pour maximiser les chances de rejouer
                var bestColor = colorGroups
                    .OrderByDescending(g => g.Count)          // Maximise la continuité de jeu
                    .ThenByDescending(g => g.TotalPoints)     // Tie-breaker : poids total
                    .First();
                return bestColor.Color;                       // Renvoie la couleur majoritaire
            }

            // Choix aléatoire si aucune carte
            var colors = new[] {                              // Fallback : palette des 4 couleurs
                CardColor.CreateTrefle(),
                CardColor.CreateCarreau(),
                CardColor.CreateCoeur(),
                CardColor.CreatePique()
            };
            return colors[random.Next(colors.Length)];        // Retourne une couleur au hasard
        }

        /// <summary>
        /// Obtient la carte intelligente selon le contexte
        /// </summary>
        public Card? GetSmartCard(                            // Routeur : choisit l’heuristique selon flags
            Player player,                                    // Joueur courant
            Card? lastCard,                                   // Dernière carte
            CardColor? chosenColor,                           // Couleur imposée éventuelle
            bool useMinimization,                             // Active la stratégie “minimisation des points”
            bool preventWin,                                  // Mode “empêcher victoire adverse”
            bool hasPenalty)                                  // Pénalité en cours
        {
            if (preventWin)                                   // Si on doit empêcher la victoire…
            {
                return GetBestCardToPreventWin(               // …on applique l’heuristique de blocage
                    player, lastCard, chosenColor, hasPenalty);
            }

            if (useMinimization)                              // Sinon, si on minimise les points…
            {
                return GetBestCardForMinimization(            // …on applique la minimisation
                    player, lastCard, chosenColor, hasPenalty);
            }

            var playableCards = rules.GetPlayableCards(       // Par défaut : stratégie triviale (première jouable)
                player.Hand, lastCard, chosenColor, hasPenalty);
            return playableCards.Count > 0 ?                  // S’il y a au moins une carte jouable…
                (Card?)playableCards.First() : null;          // …renvoyer la première, sinon null
        }
    }
}