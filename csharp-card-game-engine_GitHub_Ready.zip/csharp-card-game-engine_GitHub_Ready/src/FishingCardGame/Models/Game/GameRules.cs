﻿using System;                                               
using System.Collections.Generic;                           
using System.Linq;                                          
using FishingCardGame.Models.Structs;                       
using FishingCardGame.Models.Enums;                         
using FishingCardGame.Models.Classes;                       

namespace FishingCardGame.Models.Game                       
{
    /// <summary>
    /// Gère les règles du jeu de pêche
    /// Classe centralisant la logique de validité des coups
    /// </summary>
    public class GameRules                                  
    {
        /// <summary>
        /// Vérifie si une carte peut être jouée
        /// </summary>
        public bool CanPlayCard(                             // Règle de jouabilité d'une carte donnée le contexte
            Card cardToPlay,                                 // Carte candidate
            Card? lastCard,                                  // Dernière carte posée (null en tout début)
            CardColor? chosenColor,                          // Couleur imposée par Valet, sinon null
            bool hasPenaltyActive)                           // Indique si une pénalité +2 est en cours (chaîne de 2)
        {
            if (!lastCard.HasValue) return true;             // Première carte de la partie: tout est jouable

            // CRITICAL FIX: Jack cannot be played on 2
            if (cardToPlay.Value == CardValue.Valet &&       // Empêche précisément Valet sur un 2
                lastCard.Value.Value == CardValue.Deux)
            {
                return false;                                // Interdit Valet pour casser la chaîne de +2
            }

            // If penalty is active (2 was played), only another 2 can be played
            if (hasPenaltyActive &&                          // Si une pénalité est active ET
                lastCard.Value.Value == CardValue.Deux)      // que la pile a été posée par un 2
            {
                return cardToPlay.Value == CardValue.Deux;   // Seul un autre 2 peut être posé (contre)
            }

            if (chosenColor.HasValue)                        // Si une couleur a été choisie (Valet)
            {
                return cardToPlay.Color.Equals(chosenColor.Value) || // Couleur imposée…
                       cardToPlay.Value == CardValue.Valet;  // …ou Valet (permet de re-choisir encore)
            }

            if (cardToPlay.Value == CardValue.Valet)         // Sans couleur imposée, Valet est toujours jouable
            {
                return true;
            }

            return cardToPlay.Color.Equals(lastCard.Value.Color) ||   // Règle standard: même couleur…
                   cardToPlay.Value == lastCard.Value.Value;          // …ou même valeur
        }

        public List<Card> GetPlayableCards(                  // Filtre la main -> uniquement cartes jouables
            List<Card> hand,                                 // Main du joueur
            Card? lastCard,                                  // Dernière carte posée
            CardColor? chosenColor,                          // Couleur imposée
            bool hasPenaltyActive)                           // Pénalité en cours
        {
            if (hand == null)                                // Sécurité d’API
                throw new ArgumentNullException(nameof(hand));

            var playableCards = new List<Card>();            // Accumulateur

            if (!lastCard.HasValue)                          // Si pas de dernière carte (début)
                return new List<Card>(hand);                 // Tout est jouable → copie de la main

            foreach (var card in hand)                       // Parcourt chaque carte de la main
            {
                if (CanPlayCard(card, lastCard, chosenColor, hasPenaltyActive)) // Teste la règle
                {
                    playableCards.Add(card);                 // Ajoute si jouable
                }
            }

            return playableCards;                            // Résultat
        }

        public bool HasSpecialEffect(Card card)              // Détermine si la carte a un effet spécial
        {
            return card.Value == CardValue.As ||             // As : saut
                   card.Value == CardValue.Deux ||           // 2 : +2 (pénalité/chaînage)
                   card.Value == CardValue.Dix ||            // 10 : inversion de sens (dans tes règles)
                   card.Value == CardValue.Valet;            // Valet : choix de couleur
        }

        public bool CanCounterTwoCard(Player player)         // Le joueur peut-il “contrer” un 2 ?
        {
            return player.Hand.Any(c => c.Value == CardValue.Deux); // Oui s’il possède au moins un 2
        }
    }
}
