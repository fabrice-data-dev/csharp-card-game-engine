using System;

namespace FishingCardGame.Models.Interfaces
{
 
    public interface Person
    {
        // Propri�t� en lecture seule repr�sentant le nom de la personne
        string Nom { get; }

        // Propri�t� en lecture seule repr�sentant le pr�nom de la personne
        string Prenom { get; }

        // Propri�t� en lecture seule repr�sentant un identifiant unique (GUID)
        // Le type Guid garantit que chaque personne poss�de un identifiant globalement unique
        Guid Identifiant { get; }
    }
}