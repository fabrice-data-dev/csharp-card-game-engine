using System; 

namespace FishingCardGame.Models.Structs
{
    // D�claration d�une structure immuable (readonly struct) repr�sentant une couleur de carte
    // Elle impl�mente IEquatable<CardColor> pour permettre une comparaison efficace entre deux couleurs
    public readonly struct CardColor : IEquatable<CardColor>
    {
        private readonly string name; // Champ priv� et en lecture seule stockant le nom de la couleur (ex: "Trefle")
        private readonly int id;      // Champ priv� et en lecture seule stockant un identifiant num�rique unique

        // Constructeur priv� : emp�che la cr�ation libre d�instances � l�ext�rieur
        private CardColor(string name, int id)
        {
            this.name = name; // Affectation du nom
            this.id = id;     // Affectation de l�identifiant
        }

        // Propri�t�s statiques repr�sentant les 4 couleurs standards des cartes
        // Chaque appel cr�e une nouvelle instance de CardColor (struct l�ger, sans impact majeur)
        public static CardColor Trefle => new CardColor("Trefle", 1);
        public static CardColor Carreau => new CardColor("Carreau", 2);
        public static CardColor Coeur => new CardColor("Coeur", 3);
        public static CardColor Pique => new CardColor("Pique", 4);

        // M�thodes de fabrique explicites (�quivalentes aux propri�t�s mais plus expressives dans certaines syntaxes)
        public static CardColor CreateTrefle() => Trefle;
        public static CardColor CreateCarreau() => Carreau;
        public static CardColor CreateCoeur() => Coeur;
        public static CardColor CreatePique() => Pique;

        // Red�finition de ToString pour afficher le nom de la couleur ou "Inconnue" si null
        public override string ToString() => name ?? "Inconnue";

        // Propri�t� de validation : la couleur est valide si le nom est non vide et l�id sup�rieur � z�ro
        public bool IsValid => !string.IsNullOrEmpty(name) && id > 0;

        // Impl�mentation de IEquatable<CardColor> : comparaison bas�e sur le nom et l�identifiant
        public bool Equals(CardColor other) => id == other.id && string.Equals(name, other.name);

        // Red�finition de Equals(object) pour les comparaisons g�n�riques
        public override bool Equals(object? obj) => obj is CardColor color && Equals(color);

        // G�n�ration d�un code de hachage � partir du nom et de l�identifiant
        // Permet d�utiliser CardColor comme cl� dans des dictionnaires ou ensembles
        public override int GetHashCode() => HashCode.Combine(name, id);

        // Surcharge des op�rateurs == et != pour des comparaisons directes entre deux CardColor
        public static bool operator ==(CardColor left, CardColor right) => left.Equals(right);
        public static bool operator !=(CardColor left, CardColor right) => !left.Equals(right);
    }
}