using System; 
using FishingCardGame.Models.Enums; 

namespace FishingCardGame.Models.Structs
{
    // D�claration d�une structure repr�sentant une carte � jouer (valeur + couleur)
    // Elle impl�mente IEquatable<Card> pour permettre une comparaison directe entre cartes
    public struct Card : IEquatable<Card>
    {
        // Propri�t� en lecture seule repr�sentant la valeur de la carte (ex: As, Roi, 7...)
        public CardValue Value { get; }

        // Propri�t� en lecture seule repr�sentant la couleur (Trefle, Carreau, Coeur, Pique)
        public CardColor Color { get; }

        // Constructeur public permettant d�instancier une carte avec sa valeur et sa couleur
        public Card(CardValue value, CardColor color)
        {
            Value = value; // Affectation de la valeur de la carte
            Color = color; // Affectation de la couleur de la carte
        }

        // M�thode renvoyant le nom complet de la carte sous forme de texte (ex: "As de Coeur")
        public string GetName()
        {
            // Expression switch permettant d�associer chaque valeur de l��num�ration � son nom lisible
            var valueName = Value switch
            {
                CardValue.As => "As",
                CardValue.Deux => "2",
                CardValue.Trois => "3",
                CardValue.Quatre => "4",
                CardValue.Cinq => "5",
                CardValue.Six => "6",
                CardValue.Sept => "7",
                CardValue.Huit => "8",
                CardValue.Neuf => "9",
                CardValue.Dix => "10",
                CardValue.Valet => "Valet",
                CardValue.Dame => "Dame",
                CardValue.Roi => "Roi",
                _ => Value.ToString() // Par d�faut, renvoie le nom brut de l��num�ration si non reconnu
            };

            // Retourne une cha�ne combinant la valeur et la couleur (ex: "Roi de Pique")
            return $"{valueName} de {Color}";
        }

        // M�thode renvoyant le nombre de points attribu�s � la carte selon sa valeur
        public int GetPoints()
        {
            // Expression switch associant des points sp�cifiques � certaines valeurs
            return Value switch
            {
                CardValue.As => 11,   // L�As vaut 11 points
                CardValue.Valet => 2, // Le Valet vaut 2 points
                CardValue.Dame => 2,  // La Dame vaut 2 points
                CardValue.Roi => 2,   // Le Roi vaut 2 points
                _ => (int)Value       // Sinon, on utilise directement la valeur num�rique de l��num�ration
            };
        }

        // Propri�t� v�rifiant la validit� de la carte :
        // - La couleur doit �tre valide
        // - La valeur doit �tre comprise entre As et Roi
        public bool IsValid => Color.IsValid && Value >= CardValue.As && Value <= CardValue.Roi;

        // Red�finition de ToString pour afficher le nom complet de la carte
        public override string ToString() => GetName();

        // Impl�mentation de IEquatable<Card> : deux cartes sont �gales si elles ont m�me valeur et m�me couleur
        public bool Equals(Card other) => Value == other.Value && Color.Equals(other.Color);

        // Red�finition de Equals(object) pour la compatibilit� avec les comparaisons g�n�riques
        public override bool Equals(object? obj) => obj is Card card && Equals(card);

        // G�n�ration d�un code de hachage bas� sur la valeur et la couleur
        // Permet d�utiliser Card comme cl� dans des dictionnaires ou ensembles
        public override int GetHashCode() => HashCode.Combine(Value, Color);

        // Surcharge des op�rateurs == et != pour comparer directement deux cartes
        public static bool operator ==(Card left, Card right) => left.Equals(right);
        public static bool operator !=(Card left, Card right) => !left.Equals(right);
    }
}