﻿using System;
using System.Collections.Generic;
using FishingCardGame.Models.Structs;
using FishingCardGame.Models.Classes;

namespace FishingCardGame.Models.Events
{
    /// <summary>
    /// Arguments pour l'événement de changement de direction
    /// </summary>
    public class DirectionChangedEventArgs : EventArgs
    {
        public bool Clockwise { get; set; }              // Indique le nouveau sens du jeu : true = horaire, false = antihoraire
    }

    /// <summary>
    /// Arguments pour l'événement de joueur sauté
    /// </summary>
    public class PlayerSkippedEventArgs : EventArgs
    {
        public Player? SkippedPlayer { get; set; }       // Référence du joueur dont le tour est sauté (peut être null si non précisé)
    }

    /// <summary>
    /// Arguments pour l'événement de pénalité
    /// </summary>
    public class PenaltyEventArgs : EventArgs
    {
        public int PenaltyCount { get; set; }            // Nombre total de cartes de pénalité cumulées
    }

    /// <summary>
    /// Arguments pour l'événement de choix de couleur
    /// </summary>
    public class ColorChosenEventArgs : EventArgs
    {
        public CardColor ChosenColor { get; set; }       // Couleur choisie par un Valet (CardColor)
    }

    /// <summary>
    /// Arguments pour l'événement de carte jouée
    /// </summary>
    public class CardPlayedEventArgs : EventArgs
    {
        public Player Player { get; set; } = null!;      // Joueur ayant joué la carte (non-null une fois instancié)
        public Card Card { get; set; }                   // Carte jouée
    }

    /// <summary>
    /// Arguments pour l'événement de fin de partie
    /// </summary>
    public class GameEndedEventArgs : EventArgs
    {
        public Player? Winner { get; set; }              // Gagnant (ou null si égalité / arrêt forcé)
        public Dictionary<Player, int> Scores { get; set; } = new(); // Tableau final des scores : joueur → points
    }
}