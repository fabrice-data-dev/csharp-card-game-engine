namespace FishingCardGame.Models.Enums
{
    // Elle repr�sente toutes les valeurs possibles d�une carte dans le jeu
    public enum CardValue
    {
        As = 1,     // L�As a pour valeur num�rique 1
        Deux = 2,   // La carte 2
        Trois = 3,  // La carte 3
        Quatre = 4, // La carte 4
        Cinq = 5,   // La carte 5
        Six = 6,    // La carte 6
        Sept = 7,   // La carte 7
        Huit = 8,   // La carte 8
        Neuf = 9,   // La carte 9
        Dix = 10,   // La carte 10
        Valet = 11, // Le Valet correspond � la valeur 11
        Dame = 12,  // La Dame correspond � la valeur 12
        Roi = 13    // Le Roi correspond � la valeur 13
    }
}