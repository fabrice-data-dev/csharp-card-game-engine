// Program.cs
using System;                                  
using System.Threading.Tasks;                   
using FishingCardGame.Models.Classes;           
using FishingCardGame.Models.Game;             

namespace FishingCardGame                       
{
    public class Program                       
    {
        public static async Task Main(string[] args) 
        {
            Console.WriteLine("=== JEU DE PECHE ===\n"); 

            try                                           // Bloc de protection contre les erreurs d�ex�cution
            {
                var game = new FishingGame();            // Instancie le moteur de jeu

                var player1 = new Player("Dupont", "Jean");   // Cr�e joueur 1 (Nom, Pr�nom)
                var player2 = new Player("Martin", "Marie");  // Cr�e joueur 2
                var player3 = new Player("Bernard", "Pierre"); // Cr�e joueur 3

                game.AddPlayer(player1);                 // Ajoute le joueur 1 � la partie
                game.AddPlayer(player2);                 // Ajoute le joueur 2
                game.AddPlayer(player3);                 // Ajoute le joueur 3

                await game.StartGame(7);                 // Lance la partie avec 7 cartes par joueur (async)

                Console.WriteLine("\n=== FIN DE LA PARTIE ==="); // Bandeau de fin normal
            }
            catch (Exception ex)                          // Capture toute exception non g�r�e
            {
                Console.WriteLine($"Erreur: {ex.Message}"); // Affiche un message d�erreur lisible
            }

            Console.WriteLine("\nAppuyez sur une touche pour quitter..."); // Invite utilisateur � fermer
            Console.ReadKey();                                // Attend une touche (�vite fermeture imm�diate)
        }
    }
}